import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

export const createPost = mutation({
  args: {
    content: v.string(),
    authorId: v.string(),
    category: v.union(v.literal("ai"), v.literal("automation"), v.literal("vibe")),
    mediaType: v.union(v.literal("text"), v.literal("image"), v.literal("video")),
    mediaUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("posts", {
      ...args,
      published: true,
      createdAt: Date.now(),
    });
  },
});

export const getPostsByCategory = query({
  args: { category: v.union(v.literal("ai"), v.literal("automation"), v.literal("vibe")) },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("posts")
      .withIndex("by_category", (q) => q.eq("category", args.category))
      .filter((q) => q.eq(q.field("published"), true))
      .order("desc")
      .collect();
  },
});

export const getAllPosts = query({
  handler: async (ctx) => {
    return await ctx.db.query("posts").order("desc").collect();
  },
});

export const deletePost = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.postId);
  },
});

export const publishPost = mutation({
  args: { postId: v.id("posts"), published: v.boolean() },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.postId, { published: args.published });
  },
});

export const getAllPublishedPosts = query({
  handler: async (ctx) => {
    return await ctx.db
      .query("posts")
      .filter((q) => q.eq(q.field("published"), true))
      .order("desc")
      .collect();
  },
});
