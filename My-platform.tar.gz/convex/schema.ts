import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  users: defineTable({
    clerkId: v.string(),
    name: v.string(),
    email: v.string(),
    bio: v.optional(v.string()),
    image: v.optional(v.string()),
    role: v.union(v.literal("admin"), v.literal("user")),
    banned: v.boolean(),
    createdAt: v.number(),
  }).index("by_clerkId", ["clerkId"]),

  posts: defineTable({
    content: v.string(),
    authorId: v.string(),
    category: v.union(v.literal("ai"), v.literal("automation"), v.literal("vibe")),
    mediaType: v.union(v.literal("text"), v.literal("image"), v.literal("video")),
    mediaUrl: v.optional(v.string()),
    published: v.boolean(),
    createdAt: v.number(),
  }).index("by_category", ["category"]),

  comments: defineTable({
    postId: v.id("posts"),
    authorId: v.string(),
    authorName: v.string(),
    content: v.string(),
    createdAt: v.number(),
  }).index("by_post", ["postId"]),

  likes: defineTable({
    postId: v.id("posts"),
    userId: v.string(),
    createdAt: v.number(),
  }).index("by_post", ["postId"])
   .index("by_post_user", ["postId", "userId"]),
});
