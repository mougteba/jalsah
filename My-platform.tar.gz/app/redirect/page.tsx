"use client";
import { useUser } from "@clerk/nextjs";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";

const ADMIN_EMAIL = "almjtbymhmdalmkhtar@gmail.com";

export default function RedirectPage() {
  const { user, isLoaded } = useUser();
  const router = useRouter();
  const createOrGetUser = useMutation(api.users.createOrGetUser);

  useEffect(() => {
    if (!isLoaded || !user) return;

    const email = user.emailAddresses[0]?.emailAddress?.toLowerCase();

    const save = async () => {
      await createOrGetUser({
        clerkId: user.id,
        name: user.fullName || "مجهول",
        email: email || "",
        image: user.imageUrl,
      });

      if (email === ADMIN_EMAIL) {
        router.push("/admin");
      } else {
        router.push("/dashboard");
      }
    };

    save();
  }, [user, isLoaded]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
    </div>
  );
}
