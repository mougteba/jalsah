"use client";
import { useUser, useClerk } from "@clerk/nextjs";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";

const categories = [
  { label: "الكل", value: "all" },
  { label: "AI", value: "ai" },
  { label: "AI Automation", value: "automation" },
  { label: "Vibe Engineering", value: "vibe" },
];

function PostCard({ post, userId, userName }: { post: any; userId: string; userName: string }) {
  const [showComments, setShowComments] = useState(false);
  const [comment, setComment] = useState("");
  const likes = useQuery(api.interactions.getLikes, { postId: post._id });
  const comments = useQuery(api.interactions.getComments, { postId: post._id });
  const toggleLike = useMutation(api.interactions.toggleLike);
  const addComment = useMutation(api.interactions.addComment);
  const liked = likes?.some((l) => l.userId === userId);

  const handleComment = async () => {
    if (!comment.trim()) return;
    await addComment({ postId: post._id, authorId: userId, authorName: userName, content: comment });
    setComment("");
  };

  return (
    <div className="bg-white rounded-2xl border overflow-hidden">
      {post.mediaType === "image" && post.mediaUrl && (
        <img src={post.mediaUrl} className="w-full object-cover max-h-72" alt="" />
      )}
      {post.mediaType === "video" && post.mediaUrl && (
        <video src={post.mediaUrl} controls className="w-full max-h-72" />
      )}
      <div className="p-4">
        <p className="text-gray-800 text-sm leading-relaxed">{post.content}</p>
        <div className="flex gap-4 mt-4 pt-3 border-t">
          <button onClick={() => toggleLike({ postId: post._id, userId })}
            className={`flex items-center gap-1 text-sm ${liked ? "text-red-500" : "text-gray-400"}`}>
            {liked ? "❤️" : "🤍"} {likes?.length || 0}
          </button>
          <button onClick={() => setShowComments(!showComments)}
            className="flex items-center gap-1 text-sm text-gray-400">
            💬 {comments?.length || 0}
          </button>
        </div>
        {showComments && (
          <div className="mt-3 space-y-2">
            {comments?.map((c) => (
              <div key={c._id} className="bg-gray-50 rounded-xl px-3 py-2">
                <p className="text-xs font-medium text-gray-700">{c.authorName}</p>
                <p className="text-xs text-gray-600">{c.content}</p>
              </div>
            ))}
            <div className="flex gap-2 mt-2">
              <input value={comment} onChange={(e) => setComment(e.target.value)}
                placeholder="اكتب تعليقاً..."
                className="flex-1 border rounded-xl px-3 py-2 text-xs outline-none focus:border-black" />
              <button onClick={handleComment}
                className="bg-black text-white px-4 py-2 rounded-xl text-xs">إرسال</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function HomePage({ userId, userName }: { userId: string; userName: string }) {
  const [activeTab, setActiveTab] = useState("all");
  const allPosts = useQuery(api.posts.getAllPublishedPosts);
  const aiPosts = useQuery(api.posts.getPostsByCategory, { category: "ai" });
  const automationPosts = useQuery(api.posts.getPostsByCategory, { category: "automation" });
  const vibePosts = useQuery(api.posts.getPostsByCategory, { category: "vibe" });

  const posts = activeTab === "all" ? allPosts
    : activeTab === "ai" ? aiPosts
    : activeTab === "automation" ? automationPosts
    : vibePosts;

  return (
    <div>
      <div className="flex gap-2 px-4 pt-4 overflow-x-auto pb-2">
        {categories.map((tab) => (
          <button key={tab.value} onClick={() => setActiveTab(tab.value)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
              activeTab === tab.value ? "bg-black text-white" : "bg-white border text-gray-600"
            }`}>
            {tab.label}
          </button>
        ))}
      </div>
      <div className="px-4 pt-4 space-y-4">
        {posts?.length === 0 && (
          <div className="text-center text-gray-400 py-16">لا توجد منشورات بعد</div>
        )}
        {posts?.map((post) => (
          <PostCard key={post._id} post={post} userId={userId} userName={userName} />
        ))}
      </div>
    </div>
  );
}

function ExperiencesPage({ userId, userName }: { userId: string; userName: string }) {
  const [content, setContent] = useState("");
  const [mediaUrl, setMediaUrl] = useState("");
  const [posting, setPosting] = useState(false);
  const createPost = useMutation(api.posts.createPost);

  const handleShare = async () => {
    if (!content.trim()) return;
    setPosting(true);
    await createPost({
      content,
      authorId: userId,
      category: "ai",
      mediaType: mediaUrl ? "image" : "text",
      mediaUrl: mediaUrl || undefined,
    });
    setContent("");
    setMediaUrl("");
    setPosting(false);
  };

  return (
    <div className="px-4 pt-4 space-y-4">
      <div className="bg-white rounded-2xl border p-4 space-y-3">
        <p className="font-bold text-sm">شارك تجربتك</p>
        <textarea value={content} onChange={(e) => setContent(e.target.value)}
          placeholder="اكتب تجربتك..."
          className="w-full border rounded-xl px-4 py-3 text-sm outline-none focus:border-black min-h-24 resize-none" />
        <input value={mediaUrl} onChange={(e) => setMediaUrl(e.target.value)}
          placeholder="رابط صورة (اختياري)"
          className="w-full border rounded-xl px-4 py-3 text-sm outline-none focus:border-black" />
        <button onClick={handleShare}
          className="w-full bg-black text-white py-3 rounded-xl text-sm">
          {posting ? "جارٍ النشر..." : "نشر التجربة"}
        </button>
      </div>
    </div>
  );
}

function SettingsPage({ user, signOut }: { user: any; signOut: any }) {
  const [name, setName] = useState(user?.fullName || "");
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    const parts = name.trim().split(" ");
    await user?.update({ firstName: parts[0], lastName: parts.slice(1).join(" ") });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="px-4 pt-4 space-y-4">
      <div className="bg-white rounded-2xl border p-5 space-y-4">
        <div className="flex items-center gap-4">
          <img src={user?.imageUrl} className="w-16 h-16 rounded-full object-cover" alt="" />
          <div>
            <p className="font-bold">{user?.fullName}</p>
            <p className="text-xs text-gray-400">{user?.emailAddresses[0]?.emailAddress}</p>
            <p className="text-xs text-gray-400">انضم {new Date(user?.createdAt).toLocaleDateString("ar")}</p>
          </div>
        </div>
      </div>
      <div className="bg-white rounded-2xl border p-5 space-y-3">
        <p className="font-bold text-sm">تعديل الاسم</p>
        <input value={name} onChange={(e) => setName(e.target.value)}
          className="w-full border rounded-xl px-4 py-3 text-sm outline-none focus:border-black" />
        <button onClick={handleSave}
          className="w-full bg-black text-white py-3 rounded-xl text-sm">
          {saved ? "✓ تم الحفظ" : "حفظ"}
        </button>
      </div>
      <button onClick={() => signOut({ redirectUrl: "/" })}
        className="w-full border border-red-200 text-red-500 py-3 rounded-xl text-sm bg-white">
        تسجيل الخروج
      </button>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useUser();
  const { signOut } = useClerk();
  const [page, setPage] = useState<"home" | "experiences" | "settings">("home");

  return (
    <main dir="rtl" className="min-h-screen bg-gray-50 pb-20">
      <header className="bg-white border-b px-6 py-4 sticky top-0 z-10">
        <h1 className="text-xl font-bold text-center">جلسة</h1>
      </header>

      <div className="overflow-y-auto">
        {page === "home" && <HomePage userId={user?.id || ""} userName={user?.fullName || "مجهول"} />}
        {page === "experiences" && <ExperiencesPage userId={user?.id || ""} userName={user?.fullName || "مجهول"} />}
        {page === "settings" && <SettingsPage user={user} signOut={signOut} />}
      </div>

      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-3 z-10">
        <button onClick={() => setPage("home")}
          className={`flex flex-col items-center gap-1 text-xs ${page === "home" ? "text-black" : "text-gray-400"}`}>
          <span className="text-xl">🏠</span>
          الرئيسية
        </button>
        <button onClick={() => setPage("experiences")}
          className={`flex flex-col items-center gap-1 text-xs ${page === "experiences" ? "text-black" : "text-gray-400"}`}>
          <span className="text-xl">📖</span>
          تجارب
        </button>
        <button onClick={() => setPage("settings")}
          className={`flex flex-col items-center gap-1 text-xs ${page === "settings" ? "text-black" : "text-gray-400"}`}>
          <span className="text-xl">⚙️</span>
          إعدادات
        </button>
      </nav>
    </main>
  );
}
