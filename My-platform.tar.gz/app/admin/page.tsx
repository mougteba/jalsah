"use client";
import { useState } from "react";
import { useUser, useClerk } from "@clerk/nextjs";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";

const categories = [
  { label: "AI", value: "ai" },
  { label: "AI Automation", value: "automation" },
  { label: "Vibe Engineering", value: "vibe" },
];

function PublishPage({ user }: { user: any }) {
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<"ai" | "automation" | "vibe">("ai");
  const [mediaType, setMediaType] = useState<"text" | "image" | "video">("text");
  const [mediaUrl, setMediaUrl] = useState("");
  const [posted, setPosted] = useState(false);
  const createPost = useMutation(api.posts.createPost);

  const handlePost = async () => {
    if (!content.trim()) return;
    await createPost({ content, authorId: user?.id || "", category, mediaType, mediaUrl: mediaUrl || undefined });
    setContent(""); setMediaUrl(""); setPosted(true);
    setTimeout(() => setPosted(false), 2000);
  };

  return (
    <div className="px-4 pt-6 space-y-5">
      <div style={{background:"#111", border:"1px solid #222"}} className="rounded-2xl p-5 space-y-5">
        <p style={{color:"#C9A84C"}} className="font-semibold text-sm tracking-wider uppercase">منشور جديد</p>

        <div className="space-y-2">
          <p className="text-xs text-gray-500">الفئة</p>
          <div className="flex gap-2 flex-wrap">
            {categories.map((c) => (
              <button key={c.value} onClick={() => setCategory(c.value as any)}
                style={category === c.value ? {background:"#C9A84C", color:"#000"} : {border:"1px solid #333", color:"#888"}}
                className="px-4 py-1.5 rounded-full text-xs font-medium transition-all">
                {c.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs text-gray-500">نوع المحتوى</p>
          <div className="flex gap-2">
            {(["text","image","video"] as const).map((type) => (
              <button key={type} onClick={() => setMediaType(type)}
                style={mediaType === type ? {background:"#C9A84C", color:"#000"} : {border:"1px solid #333", color:"#888"}}
                className="px-4 py-1.5 rounded-full text-xs transition-all">
                {type === "text" ? "نص" : type === "image" ? "صورة" : "فيديو"}
              </button>
            ))}
          </div>
        </div>

        <textarea value={content} onChange={(e) => setContent(e.target.value)}
          placeholder="اكتب المنشور..."
          style={{background:"#1a1a1a", border:"1px solid #2a2a2a", color:"#f5f5f5"}}
          className="w-full rounded-xl px-4 py-3 text-sm outline-none min-h-32 resize-none placeholder-gray-600 focus:border-yellow-600 transition-colors" />

        {(mediaType === "image" || mediaType === "video") && (
          <input value={mediaUrl} onChange={(e) => setMediaUrl(e.target.value)}
            placeholder={mediaType === "image" ? "رابط الصورة..." : "رابط الفيديو..."}
            style={{background:"#1a1a1a", border:"1px solid #2a2a2a", color:"#f5f5f5"}}
            className="w-full rounded-xl px-4 py-3 text-sm outline-none placeholder-gray-600" />
        )}

        <button onClick={handlePost}
          style={{background: posted ? "#2a5a2a" : "#C9A84C", color: posted ? "#4ade80" : "#000"}}
          className="w-full py-3 rounded-xl text-sm font-semibold transition-all">
          {posted ? "✓ تم النشر" : "نشر"}
        </button>
      </div>
    </div>
  );
}

function PostsPage() {
  const posts = useQuery(api.posts.getAllPosts);
  const deletePost = useMutation(api.posts.deletePost);

  return (
    <div className="px-4 pt-6 space-y-3">
      {posts?.length === 0 && (
        <div style={{background:"#111", border:"1px solid #222"}} className="rounded-xl p-6 text-center text-gray-600">لا توجد منشورات</div>
      )}
      {posts?.map((post) => (
        <div key={post._id} style={{background:"#111", border:"1px solid #222"}} className="rounded-xl p-4 flex items-center justify-between">
          <div className="flex-1 ml-3">
            <p className="text-sm text-gray-200 line-clamp-1">{post.content}</p>
            <div className="flex gap-2 mt-1">
              <span style={{color:"#C9A84C"}} className="text-xs">{post.category}</span>
              <span className="text-xs text-gray-600">•</span>
              <span className="text-xs text-gray-600">{post.mediaType}</span>
            </div>
          </div>
          <button onClick={() => deletePost({ postId: post._id })}
            style={{border:"1px solid #3a1a1a", color:"#ef4444"}}
            className="text-xs px-3 py-1 rounded-lg shrink-0">حذف</button>
        </div>
      ))}
    </div>
  );
}

function UsersPage() {
  const users = useQuery(api.users.getAllUsers);
  const banUser = useMutation(api.users.banUser);
  const deleteUser = useMutation(api.users.deleteUser);

  return (
    <div className="px-4 pt-6 space-y-3">
      {users?.length === 0 && (
        <div style={{background:"#111", border:"1px solid #222"}} className="rounded-xl p-6 text-center text-gray-600">لا يوجد مستخدمون</div>
      )}
      {users?.map((u) => (
        <div key={u._id} style={{background:"#111", border:"1px solid #222"}} className="rounded-xl p-4 flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-200">{u.name}</p>
            <p className="text-xs text-gray-600">{u.email}</p>
            {u.banned && <span className="text-xs text-red-500">محظور</span>}
          </div>
          <div className="flex gap-2">
            <button onClick={() => banUser({ userId: u._id, banned: !u.banned })}
              style={{border:"1px solid #3a2a1a", color:"#f97316"}}
              className="text-xs px-3 py-1 rounded-lg">
              {u.banned ? "رفع الحظر" : "حظر"}
            </button>
            <button onClick={() => deleteUser({ userId: u._id })}
              style={{border:"1px solid #3a1a1a", color:"#ef4444"}}
              className="text-xs px-3 py-1 rounded-lg">حذف</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function AdminSettings({ user, signOut }: { user: any; signOut: any }) {
  return (
    <div className="px-4 pt-6 space-y-4">
      <div style={{background:"#111", border:"1px solid #222"}} className="rounded-2xl p-5">
        <div className="flex items-center gap-4">
          <img src={user?.imageUrl} className="w-14 h-14 rounded-full object-cover" style={{border:"2px solid #C9A84C"}} alt="" />
          <div>
            <p className="font-semibold text-gray-100">{user?.fullName}</p>
            <p className="text-xs text-gray-500 mt-0.5">{user?.emailAddresses[0]?.emailAddress}</p>
            <span style={{background:"#1a1500", color:"#C9A84C", border:"1px solid #3a3000"}} className="text-xs px-2 py-0.5 rounded-full mt-1 inline-block">أدمن</span>
          </div>
        </div>
      </div>
      <button onClick={() => signOut({ redirectUrl: "/" })}
        style={{border:"1px solid #3a1a1a", color:"#ef4444"}}
        className="w-full py-3 rounded-xl text-sm bg-transparent">
        تسجيل الخروج
      </button>
    </div>
  );
}

export default function AdminPage() {
  const [page, setPage] = useState<"publish"|"posts"|"users"|"settings">("publish");
  const { user } = useUser();
  const { signOut } = useClerk();

  return (
    <div style={{background:"#0a0a0a", minHeight:"100vh"}} dir="rtl" className="pb-20">
      <header style={{background:"#0a0a0a", borderBottom:"1px solid #1a1a1a"}} className="px-6 py-4 sticky top-0 z-10">
        <h1 style={{color:"#C9A84C"}} className="text-xl font-bold text-center tracking-wide">جلسة</h1>
      </header>

      {page === "publish" && <PublishPage user={user} />}
      {page === "posts" && <PostsPage />}
      {page === "users" && <UsersPage />}
      {page === "settings" && <AdminSettings user={user} signOut={signOut} />}

      <nav style={{background:"#0d0d0d", borderTop:"1px solid #1a1a1a"}} className="fixed bottom-0 left-0 right-0 flex justify-around py-3 z-10">
        {[
          { id:"publish", icon:"✏️", label:"نشر" },
          { id:"posts", icon:"📋", label:"المنشورات" },
          { id:"users", icon:"👥", label:"المستخدمون" },
          { id:"settings", icon:"⚙️", label:"إعدادات" },
        ].map((item) => (
          <button key={item.id} onClick={() => setPage(item.id as any)}
            className="flex flex-col items-center gap-1 text-xs transition-all"
            style={{color: page === item.id ? "#C9A84C" : "#444"}}>
            <span className="text-xl">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
    </div>
  );
}
