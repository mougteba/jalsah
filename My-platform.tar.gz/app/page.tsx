"use client";
import { useUser } from "@clerk/nextjs";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import Link from "next/link";

const ADMIN_EMAIL = "almjtbymhmdalmkhtar@gmail.com";

export default function Home() {
  const { user, isLoaded } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (!isLoaded || !user) return;
    const email = user.emailAddresses[0]?.emailAddress?.toLowerCase();
    if (email === ADMIN_EMAIL) {
      router.push("/admin");
    } else {
      router.push("/dashboard");
    }
  }, [user, isLoaded]);

  return (
    <main dir="rtl" className="bg-white text-black min-h-screen flex flex-col">
      <header className="flex justify-between items-center px-8 py-5 border-b sticky top-0 bg-white z-50">
        <h1 className="text-2xl font-bold">جلسة</h1>
        <Link href="/sign-in" className="border px-5 py-2 rounded-lg hover:bg-black hover:text-white transition">
          تسجيل الدخول
        </Link>
      </header>
      <section className="flex flex-col items-center justify-center text-center px-6 py-24">
        <h2 className="text-4xl font-bold mb-6 leading-tight">
          تعلّم الذكاء الاصطناعي<br /> و Vibe Coding من الصفر
        </h2>
        <p className="text-gray-600 max-w-2xl mb-10 text-lg">
          منصة "جلسة" تساعد الشباب الموريتاني على دخول عالم التقنية الحديثة، عبر محتوى عملي، مشاريع حقيقية، ومجتمع يدفعك للتطور.
        </p>
        <div className="flex gap-4 flex-wrap justify-center">
          <Link href="/sign-up" className="bg-black text-white px-8 py-4 rounded-lg hover:opacity-90 transition text-lg">ابدأ مجاناً</Link>
          <Link href="/learn" className="border px-8 py-4 rounded-lg hover:bg-black hover:text-white transition text-lg">استعرض المحتوى</Link>
        </div>
      </section>
      <section className="bg-black text-white text-center py-20 px-6">
        <h3 className="text-3xl font-bold mb-6">جاهز تبدأ رحلتك؟</h3>
        <p className="mb-8 text-gray-300">لا تنتظر، ابدأ الآن وادخل عالم الذكاء الاصطناعي.</p>
        <Link href="/sign-up" className="bg-white text-black px-8 py-4 rounded-lg hover:opacity-90 transition text-lg">ابدأ الآن مجاناً</Link>
      </section>
      <footer className="border-t text-center py-8 text-gray-500 text-sm">
        © {new Date().getFullYear()} جلسة - جميع الحقوق محفوظة
      </footer>
    </main>
  );
}
