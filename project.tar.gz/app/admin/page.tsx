"use client";
import { useState } from "react";
import { useUser, useClerk } from "@clerk/nextjs";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";

const tracks = [
  { label: "AI Foundations", value: "ai" },
  { label: "AI Automation", value: "automation" },
  { label: "Vibe Coding", value: "vibe" },
  { label: "Vibe Engineering", value: "engineering" },
];

function AddStagePage({ user }: { user: any }) {
  const [track, setTrack] = useState<"ai"|"automation"|"vibe"|"engineering">("ai");
  const [order, setOrder] = useState(1);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [externalUrl, setExternalUrl] = useState("");
  const [phase, setPhase] = useState("");
  const [questions, setQuestions] = useState([
    { text: "", type: "mcq" as "mcq"|"truefalse", options: ["","","",""], answer: "" }
  ]);
  const [saved, setSaved] = useState(false);
  const createStage = useMutation(api.stages.createStage);

  const addQuestion = () => {
    setQuestions([...questions, { text: "", type: "mcq", options: ["","","",""], answer: "" }]);
  };

  const removeQuestion = (i: number) => {
    setQuestions(questions.filter((_, idx) => idx !== i));
  };

  const updateQuestion = (i: number, field: string, value: any) => {
    const updated = [...questions];
    (updated[i] as any)[field] = value;
    setQuestions(updated);
  };

  const updateOption = (qi: number, oi: number, value: string) => {
    const updated = [...questions];
    updated[qi].options[oi] = value;
    setQuestions(updated);
  };

  const handleSave = async () => {
    if (!title || !description || !externalUrl) return;
    await createStage({
      track, order, title, description, externalUrl,
      phase: phase || undefined,
      questions: questions.map(q => ({
        text: q.text,
        type: q.type,
        options: q.type === "mcq" ? q.options.filter(o => o) : undefined,
        answer: q.answer,
      })),
    });
    setTitle(""); setDescription(""); setExternalUrl(""); setPhase("");
    setQuestions([{ text: "", type: "mcq", options: ["","","",""], answer: "" }]);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="px-4 pt-6 space-y-4 pb-6">
      <div style={{background:"#111", border:"1px solid #222"}} className="rounded-2xl p-5 space-y-4">
        <p style={{color:"#C9A84C"}} className="text-sm font-semibold uppercase tracking-wider">إضافة مرحلة جديدة</p>

        <div className="space-y-2">
          <p className="text-xs text-gray-500">المسار</p>
          <div className="flex gap-2 flex-wrap">
            {tracks.map((t) => (
              <button key={t.value} onClick={() => setTrack(t.value as any)}
                style={track === t.value ? {background:"#C9A84C", color:"#000"} : {border:"1px solid #333", color:"#888"}}
                className="px-3 py-1.5 rounded-full text-xs font-medium transition-all">
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <p className="text-xs text-gray-500">الترتيب</p>
            <input type="number" value={order} onChange={(e) => setOrder(Number(e.target.value))}
              style={{background:"#1a1a1a", border:"1px solid #2a2a2a", color:"#f5f5f5"}}
              className="w-full rounded-xl px-3 py-2 text-sm outline-none" />
          </div>
          <div className="space-y-1">
            <p className="text-xs text-gray-500">المرحلة (اختياري)</p>
            <input value={phase} onChange={(e) => setPhase(e.target.value)}
              placeholder="مثال: Vibe Engineering"
              style={{background:"#1a1a1a", border:"1px solid #2a2a2a", color:"#f5f5f5"}}
              className="w-full rounded-xl px-3 py-2 text-sm outline-none placeholder-gray-600" />
          </div>
        </div>

        <div className="space-y-1">
          <p className="text-xs text-gray-500">العنوان</p>
          <input value={title} onChange={(e) => setTitle(e.target.value)}
            placeholder="عنوان المرحلة"
            style={{background:"#1a1a1a", border:"1px solid #2a2a2a", color:"#f5f5f5"}}
            className="w-full rounded-xl px-3 py-2 text-sm outline-none placeholder-gray-600" />
        </div>

        <div className="space-y-1">
          <p className="text-xs text-gray-500">الوصف</p>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)}
            placeholder="وصف المرحلة"
            style={{background:"#1a1a1a", border:"1px solid #2a2a2a", color:"#f5f5f5"}}
            className="w-full rounded-xl px-3 py-2 text-sm outline-none min-h-20 resize-none placeholder-gray-600" />
        </div>

        <div className="space-y-1">
          <p className="text-xs text-gray-500">رابط الفيديو</p>
          <input value={externalUrl} onChange={(e) => setExternalUrl(e.target.value)}
            placeholder="https://youtube.com/..."
            style={{background:"#1a1a1a", border:"1px solid #2a2a2a", color:"#f5f5f5"}}
            className="w-full rounded-xl px-3 py-2 text-sm outline-none placeholder-gray-600" />
        </div>
      </div>

      <div style={{background:"#111", border:"1px solid #222"}} className="rounded-2xl p-5 space-y-4">
        <p style={{color:"#C9A84C"}} className="text-sm font-semibold uppercase tracking-wider">أسئلة الفهم</p>

        {questions.map((q, i) => (
          <div key={i} style={{background:"#1a1a1a", border:"1px solid #2a2a2a"}} className="rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs text-gray-500">السؤال {i + 1}</p>
              {questions.length > 1 && (
                <button onClick={() => removeQuestion(i)} className="text-xs text-red-500">حذف</button>
              )}
            </div>

            <input value={q.text} onChange={(e) => updateQuestion(i, "text", e.target.value)}
              placeholder="نص السؤال"
              style={{background:"#111", border:"1px solid #333", color:"#f5f5f5"}}
              className="w-full rounded-xl px-3 py-2 text-sm outline-none placeholder-gray-600" />

            <div className="flex gap-2">
              {(["mcq","truefalse"] as const).map((type) => (
                <button key={type} onClick={() => updateQuestion(i, "type", type)}
                  style={q.type === type ? {background:"#C9A84C", color:"#000"} : {border:"1px solid #333", color:"#888"}}
                  className="px-3 py-1 rounded-full text-xs transition-all">
                  {type === "mcq" ? "اختيار متعدد" : "صح/خطأ"}
                </button>
              ))}
            </div>

            {q.type === "mcq" && (
              <div className="space-y-2">
                {q.options.map((opt, oi) => (
                  <input key={oi} value={opt} onChange={(e) => updateOption(i, oi, e.target.value)}
                    placeholder={`الخيار ${oi + 1}`}
                    style={{background:"#111", border:"1px solid #333", color:"#f5f5f5"}}
                    className="w-full rounded-xl px-3 py-2 text-sm outline-none placeholder-gray-600" />
                ))}
              </div>
            )}

            <div className="space-y-1">
              <p className="text-xs text-gray-500">الإجابة الصحيحة</p>
              <input value={q.answer} onChange={(e) => updateQuestion(i, "answer", e.target.value)}
                placeholder={q.type === "truefalse" ? "صح أو خطأ" : "الإجابة الصحيحة بالضبط"}
                style={{background:"#111", border:"1px solid #C9A84C44", color:"#C9A84C"}}
                className="w-full rounded-xl px-3 py-2 text-sm outline-none placeholder-gray-600" />
            </div>
          </div>
        ))}

        <button onClick={addQuestion}
          style={{border:"1px solid #3a3000", color:"#C9A84C"}}
          className="w-full py-2.5 rounded-xl text-sm">
          + إضافة سؤال
        </button>
      </div>

      <button onClick={handleSave}
        style={{background: saved ? "#1a3a1a" : "#C9A84C", color: saved ? "#4ade80" : "#000"}}
        className="w-full py-4 rounded-2xl font-bold text-sm sticky bottom-20">
        {saved ? "✓ تم الحفظ" : "حفظ المرحلة"}
      </button>
    </div>
  );
}

function StagesPage() {
  const stages = useQuery(api.stages.getAllStages);
  const deleteStage = useMutation(api.stages.deleteStage);

  const trackLabel: Record<string, string> = {
    ai: "AI", automation: "Automation", vibe: "Vibe Coding", engineering: "Engineering"
  };

  return (
    <div className="px-4 pt-6 space-y-3">
      {stages?.length === 0 && (
        <div style={{background:"#111", border:"1px solid #222"}} className="rounded-xl p-6 text-center text-gray-600">
          لا توجد مراحل
        </div>
      )}
      {stages?.sort((a,b) => a.order - b.order).map((stage) => (
        <div key={stage._id} style={{background:"#111", border:"1px solid #222"}} className="rounded-xl p-4 flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-200 font-medium">{stage.title}</p>
            <div className="flex gap-2 mt-1">
              <span style={{color:"#C9A84C"}} className="text-xs">{trackLabel[stage.track]}</span>
              <span className="text-xs text-gray-600">• {stage.order}</span>
              <span className="text-xs text-gray-600">• {stage.questions.length} أسئلة</span>
            </div>
          </div>
          <button onClick={() => deleteStage({ stageId: stage._id })}
            style={{border:"1px solid #3a1a1a", color:"#ef4444"}}
            className="text-xs px-3 py-1 rounded-lg shrink-0">حذف</button>
        </div>
      ))}
    </div>
  );
}

function UsersPage() {
  const users = useQuery(api.users.getAllUsers);
  const banUser = useMutation(api.users.banUser);
  const deleteUser = useMutation(api.users.deleteUser);

  return (
    <div className="px-4 pt-6 space-y-3">
      {users?.length === 0 && (
        <div style={{background:"#111", border:"1px solid #222"}} className="rounded-xl p-6 text-center text-gray-600">لا يوجد مستخدمون</div>
      )}
      {users?.map((u) => (
        <div key={u._id} style={{background:"#111", border:"1px solid #222"}} className="rounded-xl p-4 flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-200">{u.name}</p>
            <p className="text-xs text-gray-600">{u.email}</p>
            {u.banned && <span className="text-xs text-red-500">محظور</span>}
          </div>
          <div className="flex gap-2">
            <button onClick={() => banUser({ userId: u._id, banned: !u.banned })}
              style={{border:"1px solid #3a2a1a", color:"#f97316"}}
              className="text-xs px-3 py-1 rounded-lg">
              {u.banned ? "رفع الحظر" : "حظر"}
            </button>
            <button onClick={() => deleteUser({ userId: u._id })}
              style={{border:"1px solid #3a1a1a", color:"#ef4444"}}
              className="text-xs px-3 py-1 rounded-lg">حذف</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function AdminSettings({ user, signOut }: { user: any; signOut: any }) {
  return (
    <div className="px-4 pt-6 space-y-4">
      <div style={{background:"#111", border:"1px solid #222"}} className="rounded-2xl p-5">
        <div className="flex items-center gap-4">
          <img src={user?.imageUrl} className="w-14 h-14 rounded-full object-cover"
            style={{border:"2px solid #C9A84C"}} alt="" />
          <div>
            <p className="font-semibold text-gray-100">{user?.fullName}</p>
            <p className="text-xs text-gray-500 mt-0.5">{user?.emailAddresses[0]?.emailAddress}</p>
            <span style={{background:"#1a1500", color:"#C9A84C", border:"1px solid #3a3000"}}
              className="text-xs px-2 py-0.5 rounded-full mt-1 inline-block">أدمن</span>
          </div>
        </div>
      </div>
      <button onClick={() => signOut({ redirectUrl: "/" })}
        style={{border:"1px solid #3a1a1a", color:"#ef4444"}}
        className="w-full py-3 rounded-xl text-sm bg-transparent">
        تسجيل الخروج
      </button>
    </div>
  );
}

export default function AdminPage() {
  const [page, setPage] = useState<"add"|"stages"|"users"|"settings">("add");
  const { user } = useUser();
  const { signOut } = useClerk();

  return (
    <div style={{background:"#0a0a0a", minHeight:"100vh"}} dir="rtl" className="pb-20">
      <header style={{background:"#0a0a0a", borderBottom:"1px solid #1a1a1a"}} className="px-6 py-4 sticky top-0 z-10">
        <h1 style={{color:"#C9A84C"}} className="text-xl font-bold text-center tracking-wide">لوحة التحكم</h1>
      </header>

      <div className="overflow-y-auto">
        {page === "add" && <AddStagePage user={user} />}
        {page === "stages" && <StagesPage />}
        {page === "users" && <UsersPage />}
        {page === "settings" && <AdminSettings user={user} signOut={signOut} />}
      </div>

      <nav style={{background:"#0d0d0d", borderTop:"1px solid #1a1a1a"}} className="fixed bottom-0 left-0 right-0 flex justify-around py-3 z-10">
        {[
          { id:"add", icon:"➕", label:"إضافة" },
          { id:"stages", icon:"📋", label:"المراحل" },
          { id:"users", icon:"👥", label:"المستخدمون" },
          { id:"settings", icon:"⚙️", label:"إعدادات" },
        ].map((item) => (
          <button key={item.id} onClick={() => setPage(item.id as any)}
            className="flex flex-col items-center gap-1 text-xs transition-all"
            style={{color: page === item.id ? "#C9A84C" : "#444"}}>
            <span className="text-xl">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
    </div>
  );
}
