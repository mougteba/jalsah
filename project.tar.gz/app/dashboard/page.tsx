"use client";
import { useUser, useClerk } from "@clerk/nextjs";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import Link from "next/link";
import { useState } from "react";

const tracks = [
  { id:"ai", title:"الذكاء الاصطناعي", sub:"AI Foundations", icon:"🤖", stages:6 },
  { id:"automation", title:"الأتمتة بالذكاء الاصطناعي", sub:"AI Automation", icon:"⚡", stages:6 },
  { id:"vibe", title:"Vibe Coding", sub:"من الفكرة للتطبيق", icon:"💻", stages:6 },
  { id:"engineering", title:"Vibe Engineering", sub:"المستوى المتقدم", icon:"🚀", stages:7 },
];

function HomePage({ userId }: { userId: string }) {
  const progress = useQuery(api.progress.getUserProgress, { userId });

  const getPercent = (trackId: string, total: number) => {
    if (!progress) return 0;
    const done = progress.filter(p => p.completed).length;
    return Math.min(Math.round((done / total) * 100), 100);
  };

  return (
    <div className="px-4 pt-6 space-y-4">
      <div>
        <h2 className="text-xl font-bold text-white">مساراتك</h2>
        <p className="text-gray-600 text-sm mt-1">تابع تقدمك في كل مسار</p>
      </div>
      {tracks.map((track) => {
        const percent = getPercent(track.id, track.stages);
        return (
          <Link key={track.id} href={`/tracks/${track.id}`}>
            <div style={{background:"#111", border:"1px solid #222"}}
              className="rounded-2xl p-5 space-y-3 hover:border-yellow-800 transition-colors mb-3">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{track.icon}</span>
                <div>
                  <p className="font-semibold text-white text-sm">{track.title}</p>
                  <p style={{color:"#C9A84C"}} className="text-xs">{track.sub}</p>
                </div>
                <span className="text-xs text-gray-600 mr-auto">{track.stages} مراحل</span>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-600">التقدم</span>
                  <span style={{color:"#C9A84C"}}>{percent}%</span>
                </div>
                <div style={{background:"#1a1a1a"}} className="w-full h-1.5 rounded-full overflow-hidden">
                  <div style={{width:`${percent}%`, background:"#C9A84C"}} className="h-full rounded-full transition-all" />
                </div>
              </div>
            </div>
          </Link>
        );
      })}
    </div>
  );
}

function SettingsPage({ user, signOut }: { user: any; signOut: any }) {
  const [name, setName] = useState(user?.fullName || "");
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    const parts = name.trim().split(" ");
    await user?.update({ firstName: parts[0], lastName: parts.slice(1).join(" ") });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="px-4 pt-6 space-y-4">
      <div style={{background:"#111", border:"1px solid #222"}} className="rounded-2xl p-5">
        <div className="flex items-center gap-4">
          <img src={user?.imageUrl} className="w-14 h-14 rounded-full object-cover"
            style={{border:"2px solid #C9A84C"}} alt="" />
          <div>
            <p className="font-bold text-white">{user?.fullName}</p>
            <p className="text-xs text-gray-500 mt-0.5">{user?.emailAddresses[0]?.emailAddress}</p>
            <p className="text-xs text-gray-600 mt-0.5">انضم {new Date(user?.createdAt).toLocaleDateString("ar")}</p>
          </div>
        </div>
      </div>
      <div style={{background:"#111", border:"1px solid #222"}} className="rounded-2xl p-5 space-y-3">
        <p style={{color:"#C9A84C"}} className="text-xs font-semibold uppercase tracking-wider">تعديل الاسم</p>
        <input value={name} onChange={(e) => setName(e.target.value)}
          style={{background:"#1a1a1a", border:"1px solid #2a2a2a", color:"#f5f5f5"}}
          className="w-full rounded-xl px-4 py-3 text-sm outline-none" />
        <button onClick={handleSave}
          style={{background: saved ? "#1a3a1a" : "#C9A84C", color: saved ? "#4ade80" : "#000"}}
          className="w-full py-3 rounded-xl text-sm font-semibold">
          {saved ? "✓ تم الحفظ" : "حفظ"}
        </button>
      </div>
      <button onClick={() => signOut({ redirectUrl: "/" })}
        style={{border:"1px solid #3a1a1a", color:"#ef4444"}}
        className="w-full py-3 rounded-xl text-sm bg-transparent">
        تسجيل الخروج
      </button>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useUser();
  const { signOut } = useClerk();
  const [page, setPage] = useState<"home"|"settings">("home");

  return (
    <main style={{background:"#0a0a0a", minHeight:"100vh"}} dir="rtl" className="pb-20">
      <header style={{background:"#0a0a0a", borderBottom:"1px solid #1a1a1a"}} className="px-6 py-4 sticky top-0 z-10">
        <h1 style={{color:"#C9A84C"}} className="text-xl font-bold text-center tracking-wide">جلسة</h1>
      </header>

      {page === "home" && <HomePage userId={user?.id || ""} />}
      {page === "settings" && <SettingsPage user={user} signOut={signOut} />}

      <nav style={{background:"#0d0d0d", borderTop:"1px solid #1a1a1a"}} className="fixed bottom-0 left-0 right-0 flex justify-around py-3 z-10">
        <button onClick={() => setPage("home")}
          className="flex flex-col items-center gap-1 text-xs transition-all"
          style={{color: page === "home" ? "#C9A84C" : "#444"}}>
          <span className="text-xl">🏠</span>
          الرئيسية
        </button>
        <button onClick={() => setPage("settings")}
          className="flex flex-col items-center gap-1 text-xs transition-all"
          style={{color: page === "settings" ? "#C9A84C" : "#444"}}>
          <span className="text-xl">⚙️</span>
          إعدادات
        </button>
      </nav>
    </main>
  );
}
