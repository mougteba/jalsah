"use client";
import { useUser } from "@clerk/nextjs";
import { useQuery } from "convex/react";
import { api } from "../../../convex/_generated/api";
import Link from "next/link";
import { useParams } from "next/navigation";

const trackInfo: Record<string, { title: string; icon: string; sub: string }> = {
  ai: { title: "الذكاء الاصطناعي", icon: "🤖", sub: "AI Foundations" },
  automation: { title: "الأتمتة", icon: "⚡", sub: "AI Automation" },
  vibe: { title: "Vibe Coding", icon: "💻", sub: "من الفكرة للتطبيق" },
  engineering: { title: "Vibe Engineering", icon: "🚀", sub: "المستوى المتقدم" },
};

export default function TrackPage() {
  const { user } = useUser();
  const params = useParams();
  const track = params.track as "ai"|"automation"|"vibe"|"engineering";
  const stages = useQuery(api.stages.getStagesByTrack, { track });
  const progress = useQuery(api.progress.getUserProgress, { userId: user?.id || "" });

  const isCompleted = (stageId: string) =>
    progress?.some((p) => p.stageId === stageId && p.completed);

  const isLocked = (index: number) => {
    if (index === 0) return false;
    const prevStage = stages?.[index - 1];
    if (!prevStage) return true;
    return !isCompleted(prevStage._id);
  };

  const info = trackInfo[track] || { title: "", icon: "", sub: "" };
  const completedCount = stages?.filter(s => isCompleted(s._id)).length || 0;
  const total = stages?.length || 0;

  return (
    <div style={{background:"#0a0a0a", minHeight:"100vh"}} dir="rtl" className="pb-10">
      <header style={{background:"#0a0a0a", borderBottom:"1px solid #1a1a1a"}} className="px-6 py-4 sticky top-0 z-10 flex items-center gap-3">
        <Link href="/dashboard" style={{color:"#C9A84C"}} className="text-sm">← رجوع</Link>
        <div className="flex-1">
          <h1 className="text-white font-bold text-sm">{info.icon} {info.title}</h1>
          <p style={{color:"#C9A84C"}} className="text-xs">{info.sub}</p>
        </div>
        <span className="text-xs text-gray-600">{completedCount}/{total}</span>
      </header>

      {total > 0 && (
        <div className="px-4 pt-4">
          <div style={{background:"#1a1a1a"}} className="w-full h-1 rounded-full overflow-hidden">
            <div style={{width:`${Math.round((completedCount/total)*100)}%`, background:"#C9A84C"}}
              className="h-full rounded-full transition-all" />
          </div>
        </div>
      )}

      <div className="px-4 pt-4 space-y-3">
        {stages?.length === 0 && (
          <div className="text-center text-gray-600 py-20">لا توجد مراحل بعد</div>
        )}

        {stages?.map((stage, index) => {
          const completed = isCompleted(stage._id);
          const locked = isLocked(index);

          return (
            <div key={stage._id}>
              {stage.phase && (index === 0 || stages[index-1]?.phase !== stage.phase) && (
                <div className="flex items-center gap-3 my-4">
                  <div style={{background:"#1a1a1a"}} className="flex-1 h-px" />
                  <span style={{color:"#C9A84C", border:"1px solid #3a3000", background:"#1a1500"}}
                    className="text-xs px-3 py-1 rounded-full">{stage.phase}</span>
                  <div style={{background:"#1a1a1a"}} className="flex-1 h-px" />
                </div>
              )}

              <Link href={locked ? "#" : `/tracks/${track}/${stage._id}`}>
                <div style={{
                  background: completed ? "#0d1a0d" : "#111",
                  border: completed ? "1px solid #1a3a1a" : locked ? "1px solid #1a1a1a" : "1px solid #222",
                  opacity: locked ? 0.5 : 1,
                }} className="rounded-2xl p-5 transition-all">
                  <div className="flex items-center gap-3">
                    <div style={{
                      background: completed ? "#1a3a1a" : locked ? "#1a1a1a" : "#1a1500",
                      border: completed ? "1px solid #2a5a2a" : "1px solid #2a2a00",
                      color: completed ? "#4ade80" : locked ? "#444" : "#C9A84C",
                    }} className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold shrink-0">
                      {completed ? "✓" : locked ? "🔒" : index + 1}
                    </div>
                    <div className="flex-1">
                      <p className={`font-semibold text-sm ${locked ? "text-gray-600" : "text-white"}`}>
                        {stage.title}
                      </p>
                      <p className="text-xs text-gray-600 mt-0.5 line-clamp-1">{stage.description}</p>
                    </div>
                    {completed && <span className="text-xs text-green-500">✓</span>}
                    {!locked && !completed && <span className="text-gray-600 text-xs">←</span>}
                  </div>
                </div>
              </Link>
            </div>
          );
        })}
      </div>
    </div>
  );
}
