import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

export const getComments = query({
  args: { stageId: v.id("stages") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("comments")
      .withIndex("by_stage", (q) => q.eq("stageId", args.stageId))
      .order("asc")
      .collect();
  },
});

export const addComment = mutation({
  args: {
    stageId: v.id("stages"),
    userId: v.string(),
    userName: v.string(),
    userImage: v.optional(v.string()),
    content: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("comments", {
      ...args,
      createdAt: Date.now(),
    });
  },
});
