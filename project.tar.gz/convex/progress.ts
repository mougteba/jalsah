import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

export const getUserProgress = query({
  args: { userId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("progress")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .collect();
  },
});

export const completeStage = mutation({
  args: {
    userId: v.string(),
    stageId: v.id("stages"),
    score: v.number(),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("progress")
      .withIndex("by_user_stage", (q) =>
        q.eq("userId", args.userId).eq("stageId", args.stageId)
      )
      .first();
    if (existing) {
      await ctx.db.patch(existing._id, { completed: true, score: args.score, completedAt: Date.now() });
    } else {
      await ctx.db.insert("progress", {
        userId: args.userId,
        stageId: args.stageId,
        completed: true,
        score: args.score,
        completedAt: Date.now(),
      });
    }
  },
});
